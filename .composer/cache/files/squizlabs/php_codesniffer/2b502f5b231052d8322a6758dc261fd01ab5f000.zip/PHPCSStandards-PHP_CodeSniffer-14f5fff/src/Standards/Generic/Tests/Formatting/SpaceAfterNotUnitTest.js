
if (!someVar || !x) {}
if (! someVar || ! x) {}
if (!foo() && (!x || true)) {}
var z = !(x || y);
