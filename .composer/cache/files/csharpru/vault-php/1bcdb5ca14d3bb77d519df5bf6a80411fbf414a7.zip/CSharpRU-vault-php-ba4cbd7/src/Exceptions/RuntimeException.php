<?php

namespace Vault\Exceptions;

use Exception;

/**
 * Class RuntimeException
 *
 * @package Vault\Exceptions
 */
class RuntimeException extends Exception
{
}
