<?php

namespace Vault\Exceptions;

/**
 * Class AuthenticationException
 *
 * @package Vault\Exception
 */
class AuthenticationException extends \RuntimeException
{
}