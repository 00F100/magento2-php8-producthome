<?php

namespace Laminas\Json\Exception;

class RecursionException extends RuntimeException
{
}
