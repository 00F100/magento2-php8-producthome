<?php

namespace Laminas\Json\Exception;

interface ExceptionInterface
{
}
