<?php

namespace Laminas\Json\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
