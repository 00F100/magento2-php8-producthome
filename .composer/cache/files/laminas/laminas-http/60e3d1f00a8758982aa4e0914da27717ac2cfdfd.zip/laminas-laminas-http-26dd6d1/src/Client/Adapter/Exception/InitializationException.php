<?php

namespace Laminas\Http\Client\Adapter\Exception;

class InitializationException extends RuntimeException
{
}
