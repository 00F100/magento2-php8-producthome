<?php

namespace Laminas\Http\Client\Exception;

use Laminas\Http\Exception\ExceptionInterface as HttpException;

interface ExceptionInterface extends HttpException
{
}
