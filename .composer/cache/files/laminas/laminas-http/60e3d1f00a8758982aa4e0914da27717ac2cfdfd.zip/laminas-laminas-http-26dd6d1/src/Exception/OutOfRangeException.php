<?php

namespace Laminas\Http\Exception;

class OutOfRangeException extends \OutOfRangeException implements ExceptionInterface
{
}
