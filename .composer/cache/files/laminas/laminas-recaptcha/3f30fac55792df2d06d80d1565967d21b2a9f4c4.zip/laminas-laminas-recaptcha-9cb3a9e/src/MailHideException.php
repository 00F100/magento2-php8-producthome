<?php

declare(strict_types=1);

namespace Laminas\ReCaptcha;

/**
 * @deprecated This class is deprecated and will be removed in version 4.0
 */
class MailHideException extends Exception
{
}
