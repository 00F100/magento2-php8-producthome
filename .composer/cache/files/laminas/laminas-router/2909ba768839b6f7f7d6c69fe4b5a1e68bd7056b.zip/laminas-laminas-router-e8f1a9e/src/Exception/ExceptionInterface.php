<?php

declare(strict_types=1);

namespace Laminas\Router\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}
