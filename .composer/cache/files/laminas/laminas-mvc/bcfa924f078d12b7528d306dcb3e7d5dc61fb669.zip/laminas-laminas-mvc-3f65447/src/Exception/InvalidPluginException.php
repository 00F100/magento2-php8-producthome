<?php

namespace Laminas\Mvc\Exception;

use Exception;

class InvalidPluginException extends Exception implements ExceptionInterface
{
}
