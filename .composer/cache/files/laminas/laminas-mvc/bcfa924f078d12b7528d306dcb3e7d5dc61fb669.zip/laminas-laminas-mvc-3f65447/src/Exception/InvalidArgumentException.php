<?php

namespace Laminas\Mvc\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
