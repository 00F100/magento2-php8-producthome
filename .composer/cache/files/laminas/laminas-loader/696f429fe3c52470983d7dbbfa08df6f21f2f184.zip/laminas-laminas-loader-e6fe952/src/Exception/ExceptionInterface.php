<?php

namespace Laminas\Loader\Exception;

interface ExceptionInterface
{
}
