<?php

declare(strict_types=1);

namespace Laminas\Di\Exception;

/**
 * Runtime exception for code generators
 */
class GenerateCodeException extends RuntimeException
{
}
