<?php

/**
 * @see       https://github.com/laminas/laminas-server for the canonical source repository
 */

namespace Laminas\Server\Reflection;

/**
 * Function Reflection
 */
class ReflectionFunction extends AbstractFunction
{
}
