<?php

/**
 * @see       https://github.com/laminas/laminas-server for the canonical source repository
 */

namespace Laminas\Server\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
