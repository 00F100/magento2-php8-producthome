<?php

namespace LaminasTest\OAuth\TestAsset;

use Laminas\Http\Client;

class HTTPClient19485876 extends Client
{
}
