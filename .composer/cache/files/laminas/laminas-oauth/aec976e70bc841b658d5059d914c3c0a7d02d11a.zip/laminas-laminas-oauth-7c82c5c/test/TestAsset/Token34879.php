<?php

namespace LaminasTest\OAuth\TestAsset;

class Token34879
{
    public function getToken()
    {
        return '1234567890';
    }
}
