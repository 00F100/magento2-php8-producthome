<?php

namespace LaminasTest\OAuth\TestAsset;

use Laminas\Http\Client;

class HTTPClient39745 extends Client
{
    // public function getRawData(){return $this->raw_post_data;}
}
