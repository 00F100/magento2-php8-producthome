<?php

namespace Laminas\OAuth\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{

}
