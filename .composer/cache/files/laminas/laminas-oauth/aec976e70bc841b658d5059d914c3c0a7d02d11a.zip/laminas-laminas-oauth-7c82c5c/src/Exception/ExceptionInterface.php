<?php

namespace Laminas\OAuth\Exception;

/**
 * @category   Laminas
 * @package    Laminas_OAuth
 */
interface ExceptionInterface
{

}
