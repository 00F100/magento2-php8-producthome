<?php

declare(strict_types=1);

namespace Laminas\Captcha\Exception;

use Throwable;

/**
 * Exception for Laminas\Form component.
 */
interface ExceptionInterface extends Throwable
{
}
