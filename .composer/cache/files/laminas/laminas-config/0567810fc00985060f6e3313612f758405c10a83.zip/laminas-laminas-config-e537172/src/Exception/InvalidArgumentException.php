<?php

namespace Laminas\Config\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
