<?php

namespace Laminas\File\Transfer\Exception;

use Laminas\File\Exception;

/**
 * @deprecated since 2.7.0, and scheduled for removal with 3.0.0
 */
class BadMethodCallException extends Exception\BadMethodCallException implements ExceptionInterface
{
}
