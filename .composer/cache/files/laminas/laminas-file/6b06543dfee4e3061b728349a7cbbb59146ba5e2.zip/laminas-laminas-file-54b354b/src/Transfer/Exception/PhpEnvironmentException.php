<?php

namespace Laminas\File\Transfer\Exception;

/**
 * @deprecated since 2.7.0, and scheduled for removal with 3.0.0
 */
class PhpEnvironmentException extends RuntimeException
{
}
