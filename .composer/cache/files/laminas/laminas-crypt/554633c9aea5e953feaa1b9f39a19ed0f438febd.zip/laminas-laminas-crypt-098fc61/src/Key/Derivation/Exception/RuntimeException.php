<?php

namespace Laminas\Crypt\Key\Derivation\Exception;

use Laminas\Crypt\Exception;

/**
 * Runtime argument exception
 */
class RuntimeException extends Exception\RuntimeException implements
    ExceptionInterface
{
}
