<?php

namespace Laminas\Crypt\Exception;

interface ExceptionInterface
{
}
