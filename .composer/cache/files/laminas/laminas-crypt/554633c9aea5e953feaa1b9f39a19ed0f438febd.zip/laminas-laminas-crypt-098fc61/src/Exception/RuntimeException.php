<?php

namespace Laminas\Crypt\Exception;

/**
 * Runtime argument exception
 */
class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
