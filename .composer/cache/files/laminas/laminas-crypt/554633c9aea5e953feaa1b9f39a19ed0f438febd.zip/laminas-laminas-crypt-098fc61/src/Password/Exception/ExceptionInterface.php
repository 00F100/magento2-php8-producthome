<?php

namespace Laminas\Crypt\Password\Exception;

use Laminas\Crypt\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{
}
