<?php

namespace Laminas\Math\BigInteger\Exception;

use Laminas\Math\Exception;

/**
 * Runtime exception
 */
class RuntimeException extends Exception\RuntimeException implements ExceptionInterface
{
}
