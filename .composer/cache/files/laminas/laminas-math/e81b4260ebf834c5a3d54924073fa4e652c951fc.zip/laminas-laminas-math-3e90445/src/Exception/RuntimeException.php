<?php

namespace Laminas\Math\Exception;

/**
 * Runtime argument exception
 */
class RuntimeException extends \RuntimeException implements
    ExceptionInterface
{
}
