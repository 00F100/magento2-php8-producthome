<?php

namespace Laminas\Math\Exception;

/**
 * Invalid argument exception
 */
class DomainException extends \DomainException implements ExceptionInterface
{
}
