<?php

declare(strict_types=1);

namespace Laminas\Permissions\Acl\Exception;

class RuntimeException extends \RuntimeException implements
    ExceptionInterface
{
}
