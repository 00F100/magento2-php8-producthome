<?php

declare(strict_types=1);

namespace Laminas\Permissions\Acl\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}
