<?php

namespace Laminas\I18n\Exception;

class OutOfBoundsException extends \OutOfBoundsException implements ExceptionInterface
{
}
