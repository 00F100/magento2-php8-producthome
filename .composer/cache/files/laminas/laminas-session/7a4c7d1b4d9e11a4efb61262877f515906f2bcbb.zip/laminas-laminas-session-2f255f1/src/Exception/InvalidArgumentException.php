<?php

namespace Laminas\Session\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements
    ExceptionInterface
{
}
