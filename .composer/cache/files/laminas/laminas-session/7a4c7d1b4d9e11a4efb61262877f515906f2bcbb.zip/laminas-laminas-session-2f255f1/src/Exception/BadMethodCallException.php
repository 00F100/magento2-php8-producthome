<?php

namespace Laminas\Session\Exception;

class BadMethodCallException extends \BadMethodCallException implements
    ExceptionInterface
{
}
