<?php

namespace Laminas\Session\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}
