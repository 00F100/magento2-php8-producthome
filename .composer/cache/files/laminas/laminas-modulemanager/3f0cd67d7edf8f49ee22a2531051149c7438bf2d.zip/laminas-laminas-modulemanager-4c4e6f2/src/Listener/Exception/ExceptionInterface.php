<?php

declare(strict_types=1);

namespace Laminas\ModuleManager\Listener\Exception;

use Laminas\ModuleManager\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{
}
