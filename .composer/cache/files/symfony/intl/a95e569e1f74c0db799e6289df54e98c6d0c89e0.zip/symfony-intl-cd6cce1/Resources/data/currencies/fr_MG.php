<?php

return [
    'Names' => [
        'MGA' => [
            'Ar',
            'ariary malgache',
        ],
    ],
];
