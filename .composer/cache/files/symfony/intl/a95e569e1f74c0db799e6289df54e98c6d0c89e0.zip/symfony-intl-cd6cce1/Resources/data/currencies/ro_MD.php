<?php

return [
    'Names' => [
        'MDL' => [
            'L',
            'leu moldovenesc',
        ],
    ],
];
