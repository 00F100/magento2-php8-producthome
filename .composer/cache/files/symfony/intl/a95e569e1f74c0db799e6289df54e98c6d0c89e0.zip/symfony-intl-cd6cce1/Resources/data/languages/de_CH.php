<?php

return [
    'Names' => [
        'ach' => 'Acholi-Sprache',
        'bik' => 'Bikol-Sprache',
        'chb' => 'Chibcha-Sprache',
        'din' => 'Dinka-Sprache',
        'fan' => 'Pangwe-Sprache',
        'gba' => 'Gbaya-Sprache',
        'prg' => 'Altpreussisch',
        'rhg' => 'Rohingya',
        'tgx' => 'Tagisch',
    ],
    'LocalizedNames' => [],
];
