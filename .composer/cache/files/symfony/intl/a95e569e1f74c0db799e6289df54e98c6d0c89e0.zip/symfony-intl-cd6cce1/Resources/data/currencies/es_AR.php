<?php

return [
    'Names' => [
        'ARS' => [
            '$',
            'peso argentino',
        ],
        'USD' => [
            'US$',
            'dólar estadounidense',
        ],
    ],
];
