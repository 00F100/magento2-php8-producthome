<?php

return [
    'Names' => [
        'ERN' => [
            'Nfk',
            'ናቕፋ',
        ],
    ],
];
