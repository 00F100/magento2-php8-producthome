<?php

return [
    'Names' => [
        'DJF' => [
            'Fdj',
            'Faran Jabuuti',
        ],
    ],
];
