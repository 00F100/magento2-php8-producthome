<?php

namespace PHPMD\Renderer\Option;

interface Color
{
    /**
     * @param bool $colored
     *
     * @return void
     */
    public function setColored($colored);
}
