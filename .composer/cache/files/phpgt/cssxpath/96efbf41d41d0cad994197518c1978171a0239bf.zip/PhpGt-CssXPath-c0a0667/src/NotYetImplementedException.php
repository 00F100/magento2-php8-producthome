<?php
namespace Gt\CssXPath;

class NotYetImplementedException extends CssXPathException {}
