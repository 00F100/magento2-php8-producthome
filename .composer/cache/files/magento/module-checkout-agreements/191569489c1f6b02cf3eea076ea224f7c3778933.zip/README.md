Magento\CheckoutAgreements module provides the ability add web store agreement that customers must accept before purchasing
products from store. The customer will need to accept the terms and conditions in the Order Review section of the
checkout process to be able to place an order if Terms and Conditions functionality is enabled.