# Checkout Agreements Functional Tests

The Functional Test Module for **Magento Checkout Agreements** module.
