# VaultGraphQl

**VaultGraphQl** provides type and resolver information for the GraphQl module
to generate Vault (stored payment information) information endpoints. This module also
provides mutations for modifying a payment token.
