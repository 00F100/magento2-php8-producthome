AMQP library is designed to provide default implementation for Message Queue Framework.
