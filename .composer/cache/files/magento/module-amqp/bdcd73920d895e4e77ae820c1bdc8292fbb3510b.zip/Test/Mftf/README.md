# Amqp Functional Tests

The Functional Test Module for **Magento Amqp** module.
