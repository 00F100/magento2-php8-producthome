# CheckoutAgreementsGraphQl

**CheckoutAgreementsGraphQl** provides type information for the GraphQl module
to generate Checkout Agreements fields for Checkout Agreements information endpoints.
