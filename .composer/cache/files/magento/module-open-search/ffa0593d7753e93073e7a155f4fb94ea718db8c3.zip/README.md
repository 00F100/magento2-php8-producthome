#Magento_OpenSearch module

Magento_OpenSearch module allows using OpenSearch 1.x engine for the product searching capabilities.
