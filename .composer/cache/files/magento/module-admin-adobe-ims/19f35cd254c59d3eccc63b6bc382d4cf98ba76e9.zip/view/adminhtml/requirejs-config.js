var config = {
    map: {
        '*': {
            loadIcons: 'Magento_AdminAdobeIms/js/loadicons',
            adobeImsReauth: 'Magento_AdminAdobeIms/js/adobe-ims-reauth'
        }
    }
};
