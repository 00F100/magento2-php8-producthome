# Magento_CmsPageBuilderAnalytics module

The Magento_CmsPageBuilderAnalytics module configures data definitions for a data collection related to the PageBuilder module entities to be used in [Advanced Reporting](https://devdocs.magento.com/guides/v2.4/advanced-reporting/modules.html).
