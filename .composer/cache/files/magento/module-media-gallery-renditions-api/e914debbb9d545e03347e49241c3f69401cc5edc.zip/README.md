# Magento_MediaGalleryRenditionsApi module

The Magento_MediaGalleryRenditionsApi module is responsible for the API implementation of Media Gallery Renditions.

## Installation details

For information about module installation in Magento 2, see [Enable or disable modules](https://devdocs.magento.com/guides/v2.4/install-gde/install/cli/install-cli-subcommands-enable.html).

## Additional information

For information about significant changes in patch releases, see [2.4.x Release information](https://devdocs.magento.com/guides/v2.4/release-notes/bk-release-notes.html).
