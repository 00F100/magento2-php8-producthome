# Bundle Functional Tests

The Functional Test Module for **Magento Bundle** module.
