The Magento_Vault module implements the integration with the Vault payment gateway and makes the latter available as a payment method in Magento.
