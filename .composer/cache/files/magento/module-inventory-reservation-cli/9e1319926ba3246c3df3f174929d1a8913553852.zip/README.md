# InventoryReservationCli module

The `InventoryReservationCli` module provide a cli command which helps the developer to discover inconsistencies on reservation.

This module is part of the new inventory infrastructure. The
[Inventory Management overview](https://devdocs.magento.com/guides/v2.4/inventory/index.html)
describes the MSI (Multi-Source Inventory) project in more detail.
