# Release Notification Functional Tests

The Functional Test Module for **Magento Release Notification** module.
