# SwatchesGraphQl

**SwatchesGraphQl** provides type information for the GraphQl module
to generate swatches fields for catalog and product information endpoints.
