define([
    'jquery',
], function ($) {
    $(function () {
        'use strict';

        $('#result').blur();
        $.fn.focus(function () {
        });
    });
});
