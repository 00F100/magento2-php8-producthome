define([
    'jquery',
], function (jQuery) {
    jQuery(document).ready(function () {
        'use strict';
        jQuery('#result').unload(function () {
        });
    });
});

