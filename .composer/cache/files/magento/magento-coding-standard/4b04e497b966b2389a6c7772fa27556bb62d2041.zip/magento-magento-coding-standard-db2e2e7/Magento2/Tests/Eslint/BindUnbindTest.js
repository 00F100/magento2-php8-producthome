define([
    'jquery',
], function ($) {
    $(function () {
        'use strict';

        $('.btn1').bind('click');
    });
});
