define([
    'jquery',
], function (jQuery) {
    $(function () {
        'use strict';

        jQuery.extend(jQuery.expr[':'], {});
        jQuery.extend(jQuery.expr.filters, {});
    });
});
