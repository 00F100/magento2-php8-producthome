<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Define PHP 8.1 tokens
 */
if (!defined('T_READONLY')) {
    define('T_READONLY', 42401);
}

require_once __DIR__ . '/vendor/squizlabs/php_codesniffer/tests/bootstrap.php';
