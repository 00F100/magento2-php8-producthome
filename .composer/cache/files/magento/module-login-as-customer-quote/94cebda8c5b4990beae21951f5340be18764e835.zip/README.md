# Magento_LoginAsCustomerQuote module

The Magento_LoginAsCustomerQuote module is responsible for communication between Magento_LoginAsCustomer and shopping cart state.

## Additional information

This module is a part of Login As Customer feature.

[Learn more about Login As Customer feature](https://docs.magento.com/user-guide/customers/login-as-customer.html).
