# Swatches Functional Tests

The Functional Test Module for **Magento Swatches** module.
